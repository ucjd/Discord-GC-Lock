# Discord-Lock-GC
What it do :

Basicly you cant Kick or Add anyone in a groupchat ( you dont need gc crown ) . You can add only by 1 way, you need to find it tho x).
Working on an AntiBan,Mute,LockChannel etc ... On servers. But I dont leak it yet. x)

How to use :

Replace " yourtokenhere " by your Discord Token and launch it ( line 8 ), you wait 3 seconds and when you see a " Connected Master " that pop up
you can use it :

The Command is " ;l GroupChatID "
To unlock it " ;u "

to take a groupchat id, just right click on the group chat and do " Copy ID " or search on google.

example : " ;l 982665203420385281 "

It will take 120 seconds to unlock because it rate limit a request.

You will also need Python to use it but if your not dumb you know that. Just watch a YT video or ask help.


The rule is simple :

Dont skid ( it's sourcecode because im someone cool so dont skid it )

The only real creator is me. I created that method. And I have way more to share you x)



A selfbot made by Me : Discord : " ????#???? "
The only real creator is me. I created that method. And I have way more to share you x)
